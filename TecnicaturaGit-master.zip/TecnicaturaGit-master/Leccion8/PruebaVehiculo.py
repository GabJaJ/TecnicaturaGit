from Vehiculo import *

vehiculo1 = Vehiculo ('Naranja', 4)
print(vehiculo1)




bicicleta2 = Bicicleta('Violeta', 2, 'BMX')
print(bicicleta2)