# Ejercicio 01: Crear una función para sumar los valores recibidos de tipo
# numérico, utilizando argumentos variables *args como parámetro de la
# función y agregar como resultado la suma de todos los valores pasados
# como argumento



