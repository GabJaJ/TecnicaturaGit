"""
Clase 6


Ejercicio 1

Escribir la siguiente expresion en forma de
expresion algoritmica.

[a3x (b2-2ac)]/2b

Pedimos al usuario 3 valores=a, b, c
Mostramos el resultado final


A = int(input("Ingrese el valor de "a": "))
B = int(input("Ingrese el valor de "b": "))
C = int(input("Ingrese el valor de "c": "))
Resultado = [a3x (b2-2ac)]/2b
print(resultado)

A = int(input("Ingrese el valor de A: "))
B = int(input("Ingrese el valor de B: "))
C = int(input("Ingrese el valor de C: "))
Resultado = (A*3*(B*2-2*A*C))/2*B
print(Resultado)

,<.<,.<,<.,<.,<.<,.<,<.,<.<,<.,<

Ejercicio 2

Determinar la solucion logica de la siguiente operacion.

((3+5*8)<3 and ((-6/3*4)+2<2)) or (a>b)

Solucion = (3+5*8)<3 and ((-6/3*4)+2<2) or (a>b)
print(Solucion)

,.,.<,.<,.<,.<,.<,.<.<,<.,<.<,.<<

Elercicio 3

Intercambiar el valor de dos variables
Por Ejemplo:

a=10 -> a=5
b=5 -> b=10

A = int(input("Ingrese el valor de A: "))
B = int(input("Ingrese el valor de B: "))
nuevo_val_A= B
nuevo_val_B= A
print("El nuevo valor de A es: ", nuevo_val_A)
print("El nuevo valor de B es: ", nuevo_val_B)

.<-.<,-<.,<-.,<-,<-.<,-<,<

Ejercicio 4

Area y longitud de un circulo

Hacer un programa para ingresar el radio de un
circulo
y se reporte su área y la longitud de la
circunferencia


Area = Pi * r2
Longitud = 2 * Pi * r

En este ejercicio vamos a necesitar importar el modulo math porque tiene el valor de Pi
Se escribe: import math


"""

