#Ejercicio 1: Califica tu día
#¿Cómo estuvo tu día (1 al 10)?
#Mi día estuvo de: 10

nivel = int(input("Califica tu dia del 1 al 10: "))
if nivel < 10:
    print("Mi dia estuvo de: ", nivel)
else:
    print("El valor es incorrecto")



















