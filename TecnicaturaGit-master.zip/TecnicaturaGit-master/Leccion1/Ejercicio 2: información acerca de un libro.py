#Ejercicio 2:
#Se solicita incluir la siguiente información acerca de un libro:
#titulo
#autor
#Debes imprimir la información en el siguiente formato:
#Proporciona el título:
#Proporciona el autor:
#<titulo> fue escrito por <autor>

titulo = input("Ingrese el Titulo del Libro: ")
autor = input("Ingrese el Autor: ")
print(titulo, "fue escrito por:", autor)














