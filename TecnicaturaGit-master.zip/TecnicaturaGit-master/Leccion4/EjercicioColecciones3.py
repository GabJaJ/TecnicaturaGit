# Ejercicio3: Agregar personajesa una lista
#Escribir un programa donde cree una lista con los siguientes personajes del señor de los anillos

# Nombre: Aragon
# Clase: Guerrrero
# Raza: Dúnadan del norte

# Nombre: Gandalf
# Clase: Mago
# Raza: Istar

# Nombre: Legolas
#Clase: Arquero
# Raza: Elfo Sindar

personajes = [] # Creamos una lista vacia
P = {'Nombre': 'Aragon', 'Clase': 'Guerrero', 'Raza': 'Dúnadan del Norte'}
personaje.append(P) # Agregamos a la lista de personajes
P = {'Nombre': 'Gandalf', 'Clase': 'Mago', 'Raza': 'Istar'}
personaje.append(P)
P = {'Nombre': 'Legolas', 'Clase': 'Arquero', 'Raza': 'Elfo Sindar'}
personaje.append(P)
print(personajes)






