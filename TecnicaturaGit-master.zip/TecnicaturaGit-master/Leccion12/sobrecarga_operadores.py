
a = 3
b = 5
print(a + b) # el oprador suma dos valores numericos

a = 'Hola '
b = 'Mundo'
print(a+b) # el operador esta concatenado dos cadenas

a = [3, 4, 5]
b = [6, 7, 8, 9]
print(a + b) # el operador une dos listas creando una sola

# miObjeto1 + miObjeto2 / no se puede sumar dos objeto porque hay que soobreescribir el metodo eredado del operador.

