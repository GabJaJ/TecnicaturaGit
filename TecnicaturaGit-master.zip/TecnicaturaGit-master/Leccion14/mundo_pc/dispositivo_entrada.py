class DispositivoEntrada: # esta clase solo hereda de la clase objeto haciendola independiente
    def __init__(self, marca, tipo_entrada):
        self._marca = marca   # encapsulamos los atributos
        self._tipo_entrada = tipo_entrada




